
import datetime
from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse
from core.models import PatientProfile, DoctorProfile, Report
import pytest
from django.test import RequestFactory
from core.views import psignup


class SignUpTests(TestCase):
    def test_patient_signup(self):
        expected_redirect_url = reverse('patienthome')

        response = self.client.post(reverse('psignup'), {
            'email': 'testpatient@example.com',
            'pass1': 'testpassword',
            'pass2': 'testpassword',
            'first_name': 'John',
            'last_name': 'Doe',
            'height': '180',
            'gender': 'Male',
            'bloodgroup': 'O+',
            'birthdate': '1990-01-01',
            'number': '1234567890',
        })
        self.assertEqual(response.status_code, 302)  # Check if the redirect is successful
        self.assertRedirects(response, expected_redirect_url)

    def test_patient_signup2(self):
        expected_redirect_url = reverse('psignup')

        response = self.client.post(reverse('psignup'), {
            'email': 'testpatient@example.com',
            'pass1': 'testpassworkasjbdd',
            'pass2': 'testpassword',
            'first_name': 'John',
            'last_name': 'Doe',
            'height': '180',
            'gender': 'Male',
            'bloodgroup': 'O+',
            'birthdate': '1990-01-01',
            'number': '1234567890',
        })
        self.assertEqual(response.status_code, 302)  # Check if the redirect is successful
        self.assertRedirects(response, expected_redirect_url)

    def test_doctor_signup(self):
        expected_redirect_url = reverse('homepage')
        response = self.client.post(reverse('dsignup'), {
            'email': 'testdoctor@example.com',
            'pass1': 'testpassword',
            'pass2': 'testpassword',
            'first_name': 'Dr. Jane',
            'last_name': 'Smith',
            'gender': 'Female',
            'birthdate': '1980-01-01',
            'speciality': 'Cardiologist',
            'work_address': 'Hospital XYZ',
            'number': '9876543210',
            'certificate': 'path/to/certificate.pdf',
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, expected_redirect_url)

    def test_doctor_signup2(self):
        expected_redirect_url = reverse('dsignup')
        response = self.client.post(reverse('dsignup'), {
            'email': 'testdoctor@example.com',
            'pass1': 'testpassword',
            'pass2': 'testpassword2',
            'first_name': 'Dr. Jane',
            'last_name': 'Smith',
            'gender': 'Female',
            'birthdate': '1980-01-01',
            'speciality': 'Cardiologist',
            'work_address': 'Hospital XYZ',
            'number': '9876543210',
            'certificate': 'path/to/certificate.pdf',
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, expected_redirect_url)



@pytest.mark.django_db
class TestLoginView:
    @pytest.fixture
    def client(self):
        return Client()

    @pytest.fixture
    def create_user(self):
        def _create_user(username, password):
            return User.objects.create_user(username=username, password=password)

        return _create_user

    @pytest.fixture
    def create_doctor_profile(self):
        def _create_doctor_profile(user, verified=True):
            return DoctorProfile.objects.create(user=user, Verified=verified)

        return _create_doctor_profile

    def test_login_patient_redirect(self, client, create_user):
        username = 'testuserP'
        password = 'testpassword'
        create_user(username, password)

        response = client.post(reverse('login'), {'username': username, 'password': password})

        assert response.status_code == 302
        assert response.url == reverse('patienthome')

    def test_login_doctor_verified_redirect(self, client, create_user, create_doctor_profile):
        username = 'testuserD'
        password = 'testpassword'
        user = create_user(username, password)
        create_doctor_profile(user, verified=True)

        response = client.post(reverse('login'), {'username': username, 'password': password})

        assert response.status_code == 302
        assert response.url == reverse('doctorhome')

    def test_login_doctor_not_verified(self, client, create_user, create_doctor_profile):
        username = 'testuserD'
        password = 'testpassword'
        user = create_user(username, password)
        create_doctor_profile(user, verified=False)

        response = client.post(reverse('login'), {'username': username, 'password': password})

        assert response.status_code == 302
        assert response.url == reverse('login')
        assert 'Your profile is yet to be verified' in response.content

    def test_login_invalid_credentials(self, client):
        response = client.post(reverse('login'), {'username': 'invaliduser', 'password': 'invalidpassword'})

        assert response.status_code == 302
        assert response.url == reverse('login')
        assert 'Credentials invalid' in response.content

@pytest.mark.django_db
class TestPatientHomeView:
    @pytest.fixture
    def client(self):
        return Client()

    @pytest.fixture
    def create_user(self):
        def _create_user(username, password):
            return User.objects.create_user(username=username, password=password)
        return _create_user

    @pytest.fixture
    def create_patient_profile(self):
        def _create_patient_profile(user):
            return PatientProfile.objects.create(user=user)
        return _create_patient_profile

    @pytest.fixture
    def create_report(self, create_patient_profile):
        def _create_report(patient_profile):
            return Report.objects.create(patient=patient_profile)
        return _create_report

    def test_patienthome_authenticated_user(self, client, create_user, create_patient_profile, create_report):
        username = 'testuserP'
        password = 'testpassword'
        user = create_user(username, password)
        client.force_login(user)

        patient_profile = create_patient_profile(user)
        create_report(patient_profile)

        response = client.get(reverse('patienthome'))

        assert response.status_code == 200
        assert 'patientprofile' in response.context
        assert 'reports' in response.context

    def test_patienthome_unauthenticated_user(self, client):
        response = client.get(reverse('patienthome'))

        assert response.status_code == 302
        assert response.url == reverse('login')

    def test_patienthome_no_patient_profile(self, client, create_user):
        username = 'testuserP'
        password = 'testpassword'
        user = create_user(username, password)
        client.force_login(user)

        response = client.get(reverse('patienthome'))

        assert response.status_code == 302
        assert response.url == reverse('login')

@pytest.mark.django_db
class TestDoctorHomeView:
    @pytest.fixture
    def client(self):
        return Client()

    @pytest.fixture
    def create_user(self):
        def _create_user(username, password):
            return User.objects.create_user(username=username, password=password)
        return _create_user

    @pytest.fixture
    def create_doctor_profile(self):
        def _create_doctor_profile(user):
            return DoctorProfile.objects.create(user=user)
        return _create_doctor_profile

    def test_doctorhome_authenticated_user(self, client, create_user, create_doctor_profile):
        username = 'testuserD'
        password = 'testpassword'
        user = create_user(username, password)
        create_doctor_profile(user)
        client.login(username=username, password=password)

        response = client.get(reverse('doctorhome'))

        assert response.status_code == 200
        assert 'DoctorProfile' in response.context

    def test_doctorhome_unauthenticated_user(self, client):
        response = client.get(reverse('doctorhome'))

        assert response.status_code == 302
        assert response.url == reverse('login')

    def test_doctorhome_no_doctor_profile(self, client, create_user):
        username = 'testuserD'
        password = 'testpassword'
        create_user(username, password)
        client.login(username=username, password=password)

        response = client.get(reverse('doctorhome'))

        assert response.status_code == 302
        assert response.url == reverse('login')


